                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:1721985
Glass Bed Clip (Screwless) by berky93 is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

**PLEASE NOTE:** I have received reports of these clips failing when printed in PETG. It appears they have a bit too much flex in that material. I would recommend printing these in ABS or another stiffer hi-temp material.

---

**Update 2/21/2017:** Added a longer version of the clip for users with a larger gap between the edge of the glass and the heated bed, or for users who just want a little more surface area for better holding power.

---

Simple clips to hold a glass bed securely in place. Designed to be discreet and not require any additional hardware. The glass I use is 2mm thick but the springy nature of these clips mean they should work for thicker sheets, as well. Prints quickly with no support.

# Print Settings

Printer: Wanhao Duplicator i3
Rafts: Doesn't Matter
Supports: No

Notes: 
I printed these at 10% infill but really it doesn't matter what settings you use.

___I recommend printing in ABS or another high-temp material. Make sure you use a material that prints at a higher bed temp than you normally use.___