                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3004363
Prop Gun | Revolver - Single Action by Steiner3D is licensed under the Creative Commons - Attribution - Non-Commercial - No Derivatives license.
http://creativecommons.org/licenses/by-nc-nd/3.0/

# Summary

**ATTENTION! This is not a real gun!** It cannot shoot and it was never meant to do so! There is no firing pin and the space where it would theoretically be is needed for my internal mechanics anyway.... Call it what you want, to me it's a harmless toy, a show piece, a prop, a cosplay item or whatever. But keep in mind, it may look real to people who are not aware of that. Therefor it's obviously a bad idea to carry this thing in public. However, just the fact that I feel like I have to tell you that, is already pretty sad...

**Now that we discussed that:**
**Check below for more information, requirements, issues you may encounter and how to fix the more common ones, and more!**

# Print Settings

Printer Brand: Prusa
Printer: Prusa Mk2
Rafts: No
Supports: No
Resolution: 0,15mm
Infill: 10-15%

# Introduction and Update News

Hi there! Ever wanted a Prop Revolver, that can do more than just look nice? I got you covered! I present to you, what is likely one of the first mechanically working Prop Revolvers here on thingiverse.

Go here to see it in Operation: https://i.imgur.com/DBUVUkF.gifv
It is quite well balanced, see here: https://i.imgur.com/xiP3Ovo.gifv
Update#3 introduced the Speed-Loader!: https://i.imgur.com/fzdfx1J.gifv
(3-6MB gifs, may take a while)
Go here for full-size, high-resolution **assembly drawing:** https://i.imgur.com/3nPtyNg.jpg

You made one? Awesome! Don't hesitate to share it with us!

Before we get to the important information, here are some News of previous Updates:

![Alt text](https://cdn.thingiverse.com/assets/42/33/11/46/9f/IMG_Revolver_Classic.jpg)

## 1st Update 24.09.2018 - Classic and Customization

This is the first major update.

Some may prefer a classic grip over an ergonomic synthetic one. So there you go! Just print the Revolver_Body_Classic and you are able to install the Revolver_Grip_Classic, changing the looks to fit the good old days! Therefor the Body is also slightly smaller, in case the ergonomic version does not fit on your printbed at full scale.

You think the Revolver was big enough before? Me neither! Introducing the extended Barrel with an additional 30mm in length! Furthermore, both Barrel Versions now come with an optional reinforcement rail, which makes the side profile look wider, as well as with engraved Caliber 44.Magnum text on the other side.

Want to add some color to your sights? With the new Revolver_Korn_Bicolor files you can print just the tip in some neon color, while the fixing stays within the style of the rest of the gun!

Further improvements:
- added notch on Handguard to reduce wobble after assembly. May not fit on first try, tweak carefully.
- increased strength of the leaf spring on the Flip_Switch. The Switch should reset its position more reliable now.
- Slightly reduced diameters in Cylinder_Lever to reduce wobble and added chamfers on opposite side to ease bolt insertion.
- changed Hammer and Trigger geometry for smoother operation.

![Alt text](https://cdn.thingiverse.com/assets/cb/02/fe/b9/bc/internals.jpg)

## 2nd Update 27.10.2018 - Internals reliability and quality of life improvements

This is the second update, now featuring 3rd.Generation Internals.

To me the operation was not reliable enough. Pulling the hammer a little too fast would turn the cylinder too far, pulling it very slowly would not rotate the cylinder far enough. No matter how you tuned the Internals after printing them, they would never work consistently. To get it working at all, a lot of tuning on the printed parts was necessary. This had to end!

Introducing the new Internals of the Third Generation!
Through research plus trial and error, the root causes of previous inconsistencies were identified and eliminated. The amount of time to tune the parts after printing is drastically decreased, as most parts can now be used and installed right out of the box (chapter "Afterwork" is updated accordingly)

Change notes:
- changed Revolver_Body_Top to hold the cylinder more tightly, reduced afterwork for Flip_Switch installation;
- major overhaul of Cylinder_Stopper as the model is now pre-bent (which you had to do by hand before), spring length was increased to lengthen the life time by reducing mechanical stress, nose geometry now catches the Cylinder earlier;
- the Hammer_Rotator now does not get stuck on the ammo upon flipping the Cylinder out anymore, it is slightly pre-bent, slides back over the gears more easily, increased flexibility;
- changed Revolver_Cylinder to have chamfers on ammo insertion side;
- changed Cylinder_Rotator to fit nicely into the Cylinder -> no more glue or tape necessary, also changed geometry so the angle of rotation is increased;
- Finger surface of Flip-Switch is narrower now to prevent ammo from getting stuck while emptying the Cylinder;
- reduced spring strength of Hammer lock mechanism;
- reduced spring strength of Trigger lock mechanism;

You care about the technical background? Well, here's the story:
Previously much more force was needed to fully cock the Hammer, as the locking springs of the Hammer and the Trigger were too stiff. Once you overcame the spring force, all the applied force is suddenly converted into a quick rotational momentum of the Cylinder. To prevent the Cylinder from turning too far, the Cylinder_Stopper needed to be very powerful, which resulted in increased wear of moving parts. The greater friction also caused the Cylinder to not turn far enough when the Hammer was cocked very slowly and carefully to prevent the quick rotation. With 3rdGeneration Internals, the operation is now very smooth as less force is needed. This eliminates the quick rotation and allows for a weaker but more reliable geometry of the Cylinder-Stopper. Therefor, successful catching of the Cylinder in the correct postion is now much less dependent on Cylinder rotation speed.

![Alt text](https://cdn.thingiverse.com/assets/67/87/4c/98/8a/speed-loader_branded.jpg)

## 3rd Update 05.11.2018 - Speed Loader accessory

But Steiner3D, reloading this Revolver takes ages! Aint there a faster way?? Fear not, as of Update#3, now there is! And it only consists of two parts! No springs, no screws, no supports, no glue, just true Steiner3D fashion.
Reloading the speed loader is not faster than reloading the Revolver itself, obviously. To counter that, you might as well print multiple of them, at least if you are a fanatic ;D
You can find a link to a gif in the introduction to see it in use.

Parts are sl_body and sl_button. Be sure to print the Body slowly and with enough cooling, to prevent bad printed springs. I tested multiple leaf-spring dimensions, and these seem pretty stable while having relatively low impact on operation smoothness.

It needs some force to assemble it, so be careful. The hexagonal holes must be aligned with the two spring pillars.

![Alt text](https://cdn.thingiverse.com/assets/af/ff/52/de/f0/revolver_disp-stand.jpg)

## 4th Update 20.12.2018 - Display stand & minor adjustments

Tired of leaning your fancy Revolver to a wall, a shelf, a mug or a candle because you don't want it to just lay around flat? So am I!
So there you go, print yourself the all new Display-Stand to show off what you printed! As always, parts are easy to print with flat surfaces and no supports. For the left and right support you can play around with infill patterns and leave away the solid top and bottom layers, this is how I got the Hexagons in there. If you want to include the color changes of the label into your gcode and you own a Prusa, go here: https://www.prusaprinters.org/color-print/

Minor adjustments:
- Cylinder, Cylinder-Rotator and Cylinder-Lever now have chamfers on their bottom surfaces to counteract "Elephant Foot Symptom" and reduce afterwork. Also I expect to see less comments of "Cylinder and Rotator not fitting together" now. I printed both parts again and just as before, I had zero issues, perfect fit.
- The Hammer is now available without the manually added brim, too. This should avoid future misunderstandings where people forgot to cut this brim away.
- Body and Handguard now have chamfers to better slide together.
- Both Bodies now have deeper screw holes for the Body-Top screws. These four screws can now be all of the same length and used in any length from P4x9 to P4x14.

## 5th Update 28.01.2019 - Assembly Drawing Update

Everyone had a hard time finding the right P#x# screws. That is no more! I have looked into the industry standard and all screws are now correctly named according to ISO 7049.
Happy shopping!

![Alt text](https://cdn.thingiverse.com/assets/d4/b1/62/f6/2d/IMG_animated.gif)

![Alt text](https://cdn.thingiverse.com/assets/ac/c0/07/c1/34/dual_wielding.gif)

![Alt text](https://cdn.thingiverse.com/assets/7e/a6/ed/b1/d2/speed_loader.gif)

# Core features

- Fully printable without MultiMaterial, Supports, Rafts or whatever!
- Single Action: pulling the Hammer will turn the Cylinder to the next round. Cylinder and Hammer lock into position. Pulling the trigger releases the hammer, internals are reset for next operation.
- Cylinder can be flipped out on the side to exchange the rounds
- Customizable: Ergonomic grip or Classic grip, long barrel or short barrel, combine as you like!
- Rifled barrel, though you can hardly see it (I put my phone in the space left free for the cylinder to take that shot)
- A2 size assembly drawing (check out the parts list on that one for further information)

# What you need:

- 1 M5x50 screw
- 1 M5x30 screw
- 11 screws meant for plastic/wood (labeled "ST#x#" in assembly drawing) with a length of at least 20mm and 4mm in diameter, 3mm core diameter. Cut them to shorter screws according to the parts-list on the assembly drawing (link in introduction). Leave the tip flat after cutting, but screw an unmodified screw into every hole before, the screws will not be able to cut the thread themselves anymore afterwards.
- 1 screw meant for plastic/wood (labeled "ST#x#" in assembly drawing) with a length of at least 8mm and 3mm in diameter, 2mm core diameter. Also mentioned in parts-list.
- at least approximately 73m of filament
- 1 spring as it is mentioned in the parts list. You will have to find a pen with a suitable spring, but it should be pretty common.
- M5 thread cutters for the Cylinder and the Body. Just screwing the M5s in without cutting a thread may work, but I have not tried it and would not recommend it.
- ABS filament: I heavily recommend you to use ABS for the Cylinder-Stopper, as PLA is not as flexible and will change shape under load pretty quickly. Also recommended for Trigger, Hammer and Hammer_Rotator. These likely work with PLA too (at least at first, long term is another story), but I have not tested.

# Further Information and tips

It took me around 4 weeks to design this Revolver from scratch until the object was printed and worked as intended. I googled the dimensions of a 44.Magnum cartridge and built everything around it, while the design is entirely fictional. The result is extremely satisfying!

The grip feels pretty ergonomic in my large hand. The weight distribution makes it easy to flip it in your hand.

**Not all STL files are oriented correctly** to be able to print them without supports. After correct orientation, they are! Especially for Revolver_Kimme (rear ironsights) use the large angled surface as the base (angle is 30°) for the best results. Print the classic grip on the flat bottom. Be sure to use a large brim for the barrel to make sure that it stays in place tightly. You may also want to decrease the printing speed a little, as quick movements may cause the tall object to start shaking, resulting in bad surface quality.

# Afterwork to do:

Use a lighter or some other heat source to bend the Cylinder-Stopper and the leaf spring of the Flip-Switch until they work best for you (Though latest version of Cylinder-Stopper should work right out of the box).
I advise you to test the operation multiple times before screwing it together!!
The triangular nose that keeps the Flip-Switch tight to the Body-Top will also need some afterwork until it can move smoothly.
For better adhesion I have added a bigger first layer to the gear of the Hammer, as a brim does not work properly in these tight spaces (so basically a manually added brim directly in CAD). This needs to be removed after printing! The space between the teeth should be completely free.
I have printed ALL parts with a brim. Especially the Body is suspect to warping due to many overhangs.
(Outdated, pre 2nd Update: The Hammer-Rotator may need a little tweaking at the nose that turns the gear.)

# Known issues, can I fix it?

- Hammer stops half way: adjust nose of Hammer-Rotator until it can slip over the teeth of the Cylinder-Rotator
- Cylinder spins over the notch, resulting in misalignment with the barrel: Either you are pulling the Hammer too fast, or the Cylinder-Stopper is not applying enough force. Try adjusting the bend with a heatsource.
- (Cylinder spins not well during Hammer pull: Try cutting off a little bit of the Cylinder-Stopper | Outdated, pre 2nd Update)
- (Cylinder spins not far enough to lock into a notch: Your Hammer-Rotator may be worn off. Check if there is material missing of the nose. Pulling the Hammer a little faster should work, but a fresh print is the best solution | Outdated, pre 2nd Update)
- Cylinder does not fully move back into the Revolver when it is flipped in after reloading: Caused by ammo not fully inserted and crashing into the body. Should not cause any damage, though. Just flip it back out and in again. If the barrel is pointed slightly downwards, chances of success are greatly improved.
- (Pulling the Hammer pushes the Flip-Switch back, eventually releasing the Cylinder to the side: May happen rarely. Reason is the Flip-Switch leaf spring being to soft | Outdated, pre 1st Update)
- (Loose Cylinder-Rotator: Apply multiple layers of tape to make less room for movement. You can use glue, too, but if something breaks you will have to print the entire Cylinder again | Less likely since 2nd Update)
- Flip Switch stays in position of unlocked cylinder: On the Flip Switch there is a little nose, that makes sure it stays close to the surface of the Body Top, as the screw alone does not provide enough stiffness. However, it is very likely that this nose comes out in oversize. Carefully cut or grind it until it moves without much resistance when screwed gently to the Body Top. You may also use heat on the little leaf spring to bend it and generate more tension, increasing the torque that will reset the Flip Switch to its original position on its own after operation. Remember, do not screw the Flip Switch too tight, there should be space for movement.
- (one cartridge does not come out of the cylinder: If one of the six shots is aligned with the press-spot of the Cylinder-Flip-Switch, the round will come out half way and get stuck at the flip switch. Shaking the revolver a little will fix this. A smaller Flip-Switch could fix this, but the finger rest may feel uncomfortable. A longer Cylinder-Lever could fix it too, but it will add to the overall size of the Revolver. Therefor I will not take any actions here | Outdated, pre 2nd Update)

# Conclusion

I really hope you like this thing as much as I do!
As always, feel free to comment and please share if you made one!
This was a LOT of work, so do not use or publish this thing anywhere without mentioning me as creator.

I am looking forward to see your makes!
Happy printing!

~ Steiner 3D