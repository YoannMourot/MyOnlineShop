                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3302314
Sand Belt Stand for Dremel 3000/4000 by Balthartur is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

This is an easy to build tool that I created for myself, but can very well be replicated out there.

It fits both Dremel 3000 and 4000 (see files names to download it correctly).

(WARNING: it was an experimental project. Dremels aren't the best tool to use with it because of its torque)

Besides the 3D printed parts, these are the other materials required:

– 1x Dremel 3000 or 4000
– 1x Sand belt 400x60mm (https://goo.gl/rejWYS);
– 9x M3x10 allen screws;
– 2x M3x40 allen screws;
– 1x M3x30 allen screw;
– 9x M3 nuts;
– 3x Bearings 19x6x6mm (https://goo.gl/KLgNZr);
– 8x Magnets 8x1mm (https://goo.gl/CFpL8S);
– 1x Drill bit (3mm diameter);
– Super glue or epoxy glue;

PS.: the belt does not have tension adjustment, because Dremel can't hold too much tension (at least the 3000, which is my case). What I did was to cut about 10 needle tips, heated them and fixed them in the cylinders (5 for each cylinder), leaving about 0.5 mm. This way the cylinder grabs the belt nicely.

# Print Settings

Printer Brand: Prusa
Printer: i3 MK2.5
Resolution: 0.3
Infill: 15
Filament_brand: Versamidia
Filament_color: Dark Gray and White
Filament_material: PLA

Notes: 
– No need for supports (except for one of the white cylinders);
– 3D printed parts weight a total of 200g;
– Takes about 14 hours to print at 50mm/s;

# How I Designed This

<iframe src="//www.youtube.com/embed/kZdbn9PsBNo" frameborder="0" allowfullscreen></iframe>
The video is from a previous, but very similar version of the current design.